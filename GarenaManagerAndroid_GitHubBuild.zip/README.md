# Garena Manager Android

## Build APK bằng điện thoại qua GitHub Actions
1. Tải và giải nén ZIP này trên điện thoại.
2. Mở https://github.com và đăng nhập/tạo tài khoản.
3. Tạo repository mới, ví dụ `GarenaManager`.
4. Tải toàn bộ nội dung thư mục dự án lên repository, giữ nguyên thư mục `.github/workflows`.
   - Trên giao diện GitHub điện thoại, vào repository > Add file > Upload files.
   - Nếu trình chọn file không hiện thư mục `.github`, bật hiển thị tệp ẩn hoặc dùng GitHub Desktop/web upload từ trình duyệt ở chế độ máy tính; có thể cần tải từng file/thư mục.
5. Mở tab Actions của repository.
6. Chọn workflow `Build Garena Manager APK`, bấm `Run workflow` nếu chưa tự chạy.
7. Chờ build hoàn tất (xanh lá), mở lần chạy đó, kéo xuống Artifacts.
8. Tải `GarenaManager-debug-apk`, giải nén và cài `app-debug.apk`.

## Lưu ý
- GitHub Actions chạy build trên máy chủ; điện thoại chỉ dùng để tải mã nguồn lên và tải APK về.
- Không đưa file TXT chứa tài khoản/mật khẩu lên GitHub. Chỉ upload mã nguồn.
- Đây là APK debug để cài thử, chưa phải bản phát hành ký số.
- App lưu thông tin nhập vào trong bộ nhớ ứng dụng được mã hóa bằng AndroidX Security Crypto.
- App mở trang đăng nhập Garena chính thức; người dùng tự nhập/xác nhận và tự xử lý OTP/CAPTCHA. Không có tự động thử mật khẩu hàng loạt.
