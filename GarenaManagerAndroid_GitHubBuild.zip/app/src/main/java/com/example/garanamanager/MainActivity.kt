package com.example.garenamanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF10131B)
private val Panel = Color(0xFF1B2130)
private val Accent = Color(0xFF9B7BFF)
private val Muted = Color(0xFF9AA4B5)

data class Account(val username: String, val password: String, val status: String = "Chưa xử lý")

class MainActivity : ComponentActivity() {
    private val prefs by lazy {
        val key = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            this, "secure_accounts", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, background = Bg, surface = Panel,
                    onBackground = Color.White, onSurface = Color.White
                )
            ) {
                var accounts by remember { mutableStateOf(loadAccounts()) }
                var selected by remember { mutableIntStateOf(-1) }
                var showDetail by remember { mutableStateOf(false) }
                var message by remember { mutableStateOf("Sẵn sàng nhập danh sách tài khoản") }

                val importLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.OpenDocument()
                ) { uri: Uri? ->
                    if (uri != null) {
                        try {
                            val content = contentResolver.openInputStream(uri)
                                ?.bufferedReader()?.use { it.readText() }.orEmpty()
                            val imported = content.lineSequence()
                                .map { it.trim() }
                                .filter { it.isNotBlank() && !it.startsWith("#") }
                                .mapNotNull { line ->
                                    val parts = line.split("|", limit = 2)
                                    if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank())
                                        Account(parts[0].trim(), parts[1].trim())
                                    else null
                                }.toList()
                            accounts = (accounts + imported)
                                .distinctBy { it.username }
                            saveAccounts(accounts)
                            message = "Đã nhập ${imported.size} dòng hợp lệ"
                        } catch (_: Exception) {
                            message = "Không đọc được file TXT"
                        }
                    }
                }

                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    Column(Modifier.fillMaxSize().padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, null, tint = Accent, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("GARENA MANAGER", fontWeight = FontWeight.Bold)
                                Text("QUẢN LÝ TÀI KHOẢN CỤC BỘ", color = Muted, style = MaterialTheme.typography.labelSmall)
                            }
                            AssistChip(onClick = {}, label = { Text("ANDROID") })
                        }

                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            StatCard("Tổng tài khoản", accounts.size.toString(), Modifier.weight(1f))
                            StatCard("Chưa xử lý", accounts.count { it.status == "Chưa xử lý" }.toString(), Modifier.weight(1f))
                            StatCard("Đã chọn", if (selected >= 0) "1" else "0", Modifier.weight(1f))
                        }

                        Spacer(Modifier.height(18.dp))
                        Button(
                            onClick = { importLauncher.launch(arrayOf("text/plain", "text/*")) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) {
                            Icon(Icons.Default.FileUpload, null)
                            Spacer(Modifier.width(8.dp))
                            Text("NHẬP DANH SÁCH TXT")
                        }
                        Text("Định dạng mỗi dòng: taikhoan|matkhau", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(12.dp))
                        Text(message, color = Muted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Danh sách tài khoản", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                accounts = emptyList()
                                selected = -1
                                saveAccounts(accounts)
                                message = "Đã xóa dữ liệu cục bộ"
                            }) { Text("Xóa tất cả", color = Color(0xFFFF8A8A)) }
                        }

                        if (accounts.isEmpty()) {
                            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text("Chưa có tài khoản. Hãy nhập file TXT.", color = Muted)
                            }
                        } else {
                            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(accounts.indices.toList()) { index ->
                                    val acc = accounts[index]
                                    Row(
                                        Modifier.fillMaxWidth()
                                            .background(Panel, RoundedCornerShape(14.dp))
                                            .clickable { selected = index; showDetail = true }
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.AccountCircle, null, tint = Accent, modifier = Modifier.size(28.dp))
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(acc.username, fontWeight = FontWeight.SemiBold)
                                            Text(acc.status, color = Muted, style = MaterialTheme.typography.bodySmall)
                                        }
                                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = {
                                try {
                                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://sso.garena.com/")))
                                } catch (_: Exception) { message = "Không mở được trình duyệt" }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.OpenInBrowser, null)
                            Spacer(Modifier.width(8.dp))
                            Text("MỞ TRANG ĐĂNG NHẬP GARENA")
                        }
                        Text(
                            "Ứng dụng chỉ quản lý dữ liệu cục bộ và mở trang Garena chính thức. Việc nhập mật khẩu, OTP/CAPTCHA và xác nhận đăng nhập được thực hiện trực tiếp trên trang Garena.",
                            color = Muted, style = MaterialTheme.typography.labelSmall
                        )
                    }
                }

                if (showDetail && selected in accounts.indices) {
                    val acc = accounts[selected]
                    AlertDialog(
                        onDismissRequest = { showDetail = false },
                        title = { Text("Thông tin tài khoản") },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Tên tài khoản: ${acc.username}")
                                Text("Mật khẩu: ••••••••")
                                Text("Mật khẩu được lưu mã hóa trên thiết bị.", color = Muted)
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                try {
                                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://sso.garena.com/")))
                                    accounts = accounts.toMutableList().also {
                                        it[selected] = it[selected].copy(status = "Đã mở trang Garena")
                                    }
                                    saveAccounts(accounts)
                                    message = "Đã mở trang Garena. Hãy đăng nhập thủ công."
                                } catch (_: Exception) { message = "Không mở được trang Garena" }
                                showDetail = false
                            }) { Text("Mở Garena") }
                        },
                        dismissButton = {
                            TextButton(onClick = { showDetail = false }) { Text("Đóng") }
                        }
                    )
                }
            }
        }
    }

    private fun loadAccounts(): List<Account> = try {
        val raw = prefs.getString("accounts", "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            Account(obj.getString("username"), obj.getString("password"), obj.optString("status", "Chưa xử lý"))
        }
    } catch (_: Exception) { emptyList() }

    private fun saveAccounts(accounts: List<Account>) {
        val array = JSONArray()
        accounts.forEach {
            array.put(JSONObject().put("username", it.username).put("password", it.password).put("status", it.status))
        }
        prefs.edit().putString("accounts", array.toString()).apply()
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.background(Panel, RoundedCornerShape(14.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color.White)
        Text(label, style = MaterialTheme.typography.labelSmall, color = Muted)
    }
}
